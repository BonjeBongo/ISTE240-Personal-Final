
--
-- Indexes for dumped tables
--

--
-- Indexes for table `denverComments`
--
ALTER TABLE `denverComments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `denverFeedback`
--
ALTER TABLE `denverFeedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `denverPages`
--
ALTER TABLE `denverPages`
  ADD PRIMARY KEY (`pgName`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `denverComments`
--
ALTER TABLE `denverComments`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT for table `denverFeedback`
--
ALTER TABLE `denverFeedback`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;